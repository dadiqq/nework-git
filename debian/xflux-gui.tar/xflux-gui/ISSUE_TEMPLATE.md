Before opening a new issue for a bug, please:

1. Check that you're not experiencing an existing issue. In particular, [Issue #27](https://github.com/xflux-gui/xflux-gui/issues/27) is very common.

2. Install `xflux-gui` from source if you used the PPA and the PPA is stale. This [is easy to do](https://github.com/xflux-gui/xflux-gui/blob/master/README.md) and ensures your issue isn't already fixed.

Thanks!
